// Device VRAM calculation, changing the 3D Scene to video if the rendering power is low

import { Application } from "@splinetool/runtime";

// Constants
const VIDEO_URLS = {
  poster: "https://cdn.glitch.global/8352fc0e-bebe-4680-ae0b-269da8b54259/hero-placeholder.webp",
  mp4: "https://cdn.glitch.global/8352fc0e-bebe-4680-ae0b-269da8b54259/home-hero.mp4",
  webm: "https://cdn.glitch.global/8352fc0e-bebe-4680-ae0b-269da8b54259/home-hero.webm",
};

const SELECTORS = {
  sceneHolder: "#sceneHolder",
  loadingSection: ".loadingSection",
  loadingCounter: "#loadingCounter",
  mainText: "#mainText",
  canvas3d: "#canvas3d",
};

const checkGraphicsCapability = () => {
  try {
    const gl = document.createElement("canvas").getContext("webgl") || document.createElement("canvas").getContext("experimental-webgl");
    if (!gl) return false;

    const maxTextureSize = gl.getParameter(gl.MAX_TEXTURE_SIZE);
    const precision = gl.getShaderPrecisionFormat(gl.VERTEX_SHADER, gl.HIGH_FLOAT).precision > 0;
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

    return maxTextureSize >= 8192 && precision && navigator.hardwareConcurrency >= 8 && !isMobile;
  } catch {
    return false;
  }
};

const createVideoElement = () => {
  const video = document.createElement("video");
  video.className = "headerVid";
  video.setAttribute("width", "100%");
  video.setAttribute("height", "100%");
  video.poster = VIDEO_URLS.poster;
  video.autoplay = true;
  video.muted = true;
  video.loop = true;
  video.playsInline = true;

  const mp4 = document.createElement("source");
  mp4.src = VIDEO_URLS.mp4;
  mp4.type = "video/mp4";
  video.appendChild(mp4);

  const webm = document.createElement("source");
  webm.src = VIDEO_URLS.webm;
  webm.type = "video/webm";
  video.appendChild(webm);

  return video;
};

const createLoadingCounter = (callback) => {
  let counter = 0;
  const counterEl = document.querySelector(SELECTORS.loadingCounter);

  const update = () => {
    if (counter < 100) {
      counterEl.textContent = counter + "%";
      counter++;
      setTimeout(update, 50);
    } else {
      callback();
    }
  };
  update();
};

const finishLoading = () => {
  document.querySelector(SELECTORS.loadingCounter).textContent = "100%";
  document.querySelector(SELECTORS.loadingSection).style.opacity = "0";
  document.body.style.overflow = "auto";
};

const appendVideoToScene = (container, showText = false) => {
  container.innerHTML = "";
  const video = createVideoElement();
  container.appendChild(video);

  if (showText) {
    const mainText = document.querySelector(SELECTORS.mainText);
    mainText.style.display = "flex";
    mainText.style.opacity = 1;
  }

  createLoadingCounter(finishLoading);

  video.addEventListener("canplaythrough", finishLoading, { once: true });
  video.addEventListener("error", () => {
    console.error("Error loading the video.");
    document.querySelector(SELECTORS.loadingCounter).textContent = "Load Error";
  });
};

const checkVRAMAndWebGLSupport = () => {
  if (!checkGraphicsCapability()) {
    appendVideoToScene(document.querySelector(SELECTORS.sceneHolder), true);
    return;
  }

  const sceneHolder = document.querySelector(SELECTORS.sceneHolder);
  const canvas3D = document.createElement("canvas");
  canvas3D.className = "header3D";
  canvas3D.id = "canvas3d";
  sceneHolder.appendChild(canvas3D);

  const app = new Application(canvas3D);

  createLoadingCounter(() => {
  });

  app
    .load("../src/treeJs/scene.splinecode")
    .then(() => finishLoading())
    .catch((error) => {
      console.error("Error loading 3D scene:", error);
      document.querySelector(SELECTORS.loadingCounter).textContent = "Load Error";
      setTimeout(() => appendVideoToScene(sceneHolder), 1000);
    });
};

checkVRAMAndWebGLSupport();
